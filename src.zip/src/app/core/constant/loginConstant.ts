export class loginConstant {
    onSignup = {
        text: "Setup Your Account!",
        subtext: "We will send you a link for resetting your password to your registered email.",
        button: 'Register'
    }
    onForgotPassword = {
        text: "Forgot Your Password?",
        subtext: "We will send you a link for resetting your password to your registered email.",
        button: 'Reset Password'
    }
    navigationList = [
        { image: './assets/user-info.png', name: 'My Info' }
    ]
}