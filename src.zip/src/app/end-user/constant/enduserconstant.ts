export class enduserconstant {

  gender = [
    'Male',
    'Female',
    'Trans gender'
  ]
  maritalStatus = [
    'Married',
    'Un-married'
  ]

  contactinfoSubdivisions = ["Present Address", "Permanent Address", "Emergency Contact"];
}